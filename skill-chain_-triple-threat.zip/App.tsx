
import React, { useState, useEffect } from 'react';
import { Chain, ChainStatus, User, RoundStatus } from './types';
import { gameService } from './services/gameService';
import SkillTask from './components/SkillTask';

const initiatePayment = (amount: number, callback: (response: any) => void) => {
  const win = window as any;
  if (win.Razorpay) {
    const options = {
      key: "rzp_test_dummykey",
      amount: amount * 100,
      currency: "INR",
      name: "Skill Chain",
      description: "Participation Fee",
      handler: callback,
      prefill: { name: "Player", email: "player@game.com", contact: "9876543210" },
      theme: { color: "#4f46e5" }
    };
    const rzp = new win.Razorpay(options);
    rzp.open();
  } else {
    setTimeout(() => callback({ razorpay_payment_id: "pay_mock_" + Date.now() }), 800);
  }
};

const App: React.FC = () => {
  const [view, setView] = useState<'HOME' | 'INSTRUCTIONS' | 'REGISTER' | 'CHECKOUT' | 'SKILL_TASK' | 'GAME_BOARD' | 'STATUS'>('HOME');
  const [currentUser, setCurrentUser] = useState<User | null>(gameService.getCurrentUser());
  const [chains, setChains] = useState<Chain[]>(gameService.getChains());
  const [selectedChainId, setSelectedChainId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState({ title: '', body: '', isWin: false });
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => setChains(gameService.updateTimers()), 1000);
    return () => clearInterval(interval);
  }, []);

  const handleJoinRequest = (chainId: string | null) => {
    setSelectedChainId(chainId);
    setView('INSTRUCTIONS');
  };

  const handleRegister = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const user = gameService.registerUser(
      fd.get('name') as string,
      fd.get('mobile') as string,
      fd.get('upi') as string
    );
    setCurrentUser(user);
    setView('CHECKOUT');
  };

  const onPaymentSuccess = () => setView('SKILL_TASK');

  const onSkillSuccess = () => {
    if (!currentUser) return;
    if (gameService.getRoundStatus() === RoundStatus.COMPLETED) {
      setStatusMessage({ title: 'ROUND OVER', body: 'Someone already won this round while you were playing. Better luck next time!', isWin: false });
      setView('STATUS');
      return;
    }

    const result = selectedChainId 
      ? gameService.joinChain(selectedChainId, currentUser) 
      : gameService.startChain(currentUser);

    if (result?.status === ChainStatus.WON) {
      setStatusMessage({
        title: '🏆 YOU WON ₹500!',
        body: 'Congratulations! Your team was the FASTEST. Payout will be sent manually to your UPI ID within 24 hours.',
        isWin: true
      });
      setView('STATUS');
    } else {
      setView('GAME_BOARD');
    }
  };

  const onSkillFail = () => {
    if (selectedChainId) gameService.failChain(selectedChainId);
    setStatusMessage({ title: 'FAILED', body: 'Skill task failed or tab switched. This chain is now locked.', isWin: false });
    setView('STATUS');
  };

  const HomeView = () => (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 space-y-10">
      <div className="text-center space-y-2">
        <h1 className="text-6xl font-black italic tracking-tighter text-indigo-500">SPEED CHAIN</h1>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">A Fast-Paced Skill Game</p>
      </div>

      <div className="w-full max-w-xs space-y-4">
        <button 
          onClick={() => handleJoinRequest(null)}
          className="w-full py-5 bg-indigo-600 rounded-3xl text-xl font-black shadow-xl shadow-indigo-600/30 transform active:scale-95 transition-all"
        >
          START ROUND (₹20)
        </button>
        <button 
          onClick={() => setView('GAME_BOARD')}
          className="w-full py-4 bg-slate-900 border-2 border-slate-800 rounded-3xl font-bold"
        >
          JOIN ACTIVE TEAMS
        </button>
      </div>

      <div className="bg-slate-900 p-6 rounded-3xl border border-indigo-500/20 max-w-xs text-xs space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold">1</div>
          <p className="text-slate-300">Pay ₹20 participation fee.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold">2</div>
          <p className="text-slate-300">Pass the Human Skill Check.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold">3</div>
          <p className="text-slate-300">Fastest 3-person team wins ₹500.</p>
        </div>
      </div>
      
      <p className="text-[10px] text-slate-600 uppercase font-bold text-center">Skill-based promotional game. No gambling.</p>
    </div>
  );

  const InstructionsView = () => (
    <div className="p-6 max-w-sm mx-auto space-y-8 py-10">
      <div className="space-y-4">
        <h2 className="text-3xl font-black text-indigo-500">🔥 IMPORTANT</h2>
        <div className="bg-slate-900 p-6 rounded-3xl border-2 border-red-500/20 space-y-4">
          <p className="font-bold text-red-400">This is a speed-based skill game.</p>
          <ul className="text-sm text-slate-300 space-y-2 list-disc list-inside">
            <li>Only the <span className="text-white font-bold underline">FASTEST</span> 3-player team wins.</li>
            <li>Completing the chain does NOT guarantee a win.</li>
            <li>The round ends immediately when one team wins.</li>
          </ul>
        </div>
      </div>

      <label className="flex items-start gap-4 p-4 bg-slate-900 rounded-2xl cursor-pointer">
        <input 
          type="checkbox" 
          checked={agreedToTerms} 
          onChange={e => setAgreedToTerms(e.target.checked)}
          className="mt-1 w-5 h-5 rounded accent-indigo-500"
        />
        <span className="text-xs font-bold text-slate-400 leading-tight">
          I understand that only the fastest team wins and ₹20 is a non-refundable participation fee.
        </span>
      </label>

      <button 
        disabled={!agreedToTerms}
        onClick={() => currentUser ? setView('CHECKOUT') : setView('REGISTER')}
        className={`w-full py-4 rounded-2xl font-black transition-all ${agreedToTerms ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-800 text-slate-600 grayscale'}`}
      >
        PROCEED TO JOIN
      </button>
    </div>
  );

  const RegisterView = () => (
    <form onSubmit={handleRegister} className="p-6 py-12 space-y-6 max-w-sm mx-auto">
      <h2 className="text-3xl font-black text-center mb-10">WHO ARE YOU?</h2>
      <div className="space-y-4">
        <input required name="name" className="w-full bg-slate-900 p-5 rounded-2xl border-2 border-slate-800 focus:border-indigo-500 outline-none" placeholder="FULL NAME" />
        <input required name="mobile" className="w-full bg-slate-900 p-5 rounded-2xl border-2 border-slate-800 focus:border-indigo-500 outline-none" placeholder="MOBILE NUMBER" />
        <input required name="upi" className="w-full bg-slate-900 p-5 rounded-2xl border-2 border-slate-800 focus:border-indigo-500 outline-none" placeholder="UPI ID (TO RECEIVE ₹500)" />
      </div>
      <button type="submit" className="w-full py-5 bg-indigo-600 rounded-2xl font-black shadow-xl">CONTINUE</button>
    </form>
  );

  const CheckoutView = () => (
    <div className="p-8 py-20 text-center max-w-sm mx-auto space-y-10">
      <div className="space-y-2">
        <div className="text-6xl font-black italic">₹20</div>
        <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Participation Fee</p>
      </div>
      <button 
        onClick={() => initiatePayment(20, onPaymentSuccess)}
        className="w-full py-5 bg-indigo-600 rounded-2xl font-black text-xl shadow-2xl shadow-indigo-600/40"
      >
        PAY & START TASK
      </button>
      <button onClick={() => setView('HOME')} className="text-slate-500 font-bold">CANCEL</button>
    </div>
  );

  const GameBoardView = () => (
    <div className="p-4 py-8 space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-black italic">ACTIVE ROUND</h2>
        <button onClick={() => setView('HOME')} className="text-indigo-400 font-bold px-4">BACK</button>
      </div>

      {gameService.getRoundStatus() === RoundStatus.COMPLETED ? (
        <div className="bg-slate-900 p-10 rounded-3xl text-center border-2 border-indigo-500/20">
          <p className="text-2xl font-black mb-2">ROUND COMPLETED</p>
          <p className="text-slate-500 text-sm">Next round starts soon. Check back in a few minutes!</p>
          <button onClick={() => { gameService.resetRound(); setView('HOME'); }} className="mt-6 text-xs text-indigo-500 underline font-bold">RESET (DEMO ONLY)</button>
        </div>
      ) : chains.length === 0 ? (
        <div className="bg-slate-900 p-12 rounded-3xl text-center border-2 border-slate-800">
          <p className="text-slate-500 font-bold">NO TEAMS RACING YET</p>
          <button onClick={() => handleJoinRequest(null)} className="mt-4 text-indigo-500 font-bold border-b-2 border-indigo-500 pb-1">BE THE FIRST</button>
        </div>
      ) : (
        <div className="space-y-4">
          {chains.map(chain => (
            <div key={chain.id} className="bg-slate-900 border-2 border-slate-800 rounded-3xl p-6 relative overflow-hidden">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <p className="text-[10px] font-black text-indigo-500">{chain.id}</p>
                  <p className="text-lg font-black italic leading-none">TEAM CHAIN</p>
                </div>
                <div className="text-right">
                  <p className={`text-2xl font-mono font-black ${chain.timeLeft < 15 ? 'text-red-500 animate-pulse' : 'text-indigo-400'}`}>{chain.timeLeft}s</p>
                </div>
              </div>

              <div className="flex justify-between gap-2 mb-8">
                {[chain.starter, chain.connector, chain.finisher].map((u, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl border-2 transition-all ${u ? 'bg-indigo-600 border-indigo-400 shadow-lg' : 'bg-slate-800 border-slate-700 text-slate-600'}`}>
                      {u ? u.name[0].toUpperCase() : i + 1}
                    </div>
                  </div>
                ))}
              </div>

              <button 
                disabled={!!chain.finisher || (currentUser && [chain.starter?.id, chain.connector?.id].includes(currentUser.id))}
                onClick={() => handleJoinRequest(chain.id)}
                className="w-full py-4 bg-white text-slate-950 rounded-2xl font-black uppercase text-sm tracking-widest hover:bg-indigo-50 disabled:opacity-30"
              >
                JOIN & COMPETE
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-md mx-auto min-h-screen bg-slate-950 font-sans selection:bg-indigo-500 selection:text-white">
      <nav className="p-6 flex justify-between items-center border-b border-slate-900 sticky top-0 bg-slate-950/80 backdrop-blur-lg z-50">
        <div onClick={() => setView('HOME')} className="text-2xl font-black italic tracking-tighter cursor-pointer">
          S<span className="text-indigo-500">CHAIN</span>
        </div>
        {currentUser && (
          <div className="bg-slate-900 px-4 py-2 rounded-full border border-slate-800 flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] font-black tracking-widest uppercase">{currentUser.name.split(' ')[0]}</span>
          </div>
        )}
      </nav>

      <main>
        {view === 'HOME' && <HomeView />}
        {view === 'INSTRUCTIONS' && <InstructionsView />}
        {view === 'REGISTER' && <RegisterView />}
        {view === 'CHECKOUT' && <CheckoutView />}
        {view === 'SKILL_TASK' && <div className="py-20 px-4"><SkillTask onSuccess={onSkillSuccess} onFail={onSkillFail} /></div>}
        {view === 'GAME_BOARD' && <GameBoardView />}
        {view === 'STATUS' && (
          <div className="p-10 py-32 text-center space-y-8">
            <div className={`text-8xl ${statusMessage.isWin ? 'animate-bounce' : 'grayscale'}`}>{statusMessage.isWin ? '🏆' : '💀'}</div>
            <h2 className="text-4xl font-black italic leading-tight">{statusMessage.title}</h2>
            <p className="text-slate-400 font-bold px-6">{statusMessage.body}</p>
            <button onClick={() => setView('HOME')} className="w-full py-5 bg-indigo-600 rounded-3xl font-black shadow-xl max-w-xs mx-auto">BACK TO HUB</button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;


import { Chain, ChainStatus, User, RoundStatus } from '../types';

const STORAGE_KEY = 'skill_chain_data_v3';

interface GameData {
  chains: Chain[];
  users: User[];
  currentUser: User | null;
  roundStatus: RoundStatus;
  roundWinnerId: string | null;
}

class GameService {
  private data: GameData;

  constructor() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        this.data = JSON.parse(saved);
      } else {
        this.data = this.getInitialData();
      }
    } catch (e) {
      this.data = this.getInitialData();
    }
  }

  private getInitialData(): GameData {
    return {
      chains: [],
      users: [],
      currentUser: null,
      roundStatus: RoundStatus.OPEN,
      roundWinnerId: null
    };
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    } catch (e) {}
  }

  getCurrentUser() { return this.data.currentUser; }
  getRoundStatus() { return this.data.roundStatus; }

  registerUser(name: string, mobile: string, upi: string) {
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: name.trim(),
      mobile: mobile.trim(),
      upi: upi.trim(),
      verified: true
    };
    this.data.users.push(newUser);
    this.data.currentUser = newUser;
    this.save();
    return newUser;
  }

  updateUser(updates: Partial<User>) {
    if (this.data.currentUser) {
      this.data.currentUser = { ...this.data.currentUser, ...updates };
      const idx = this.data.users.findIndex(u => u.id === this.data.currentUser?.id);
      if (idx !== -1) this.data.users[idx] = this.data.currentUser;
      this.save();
    }
    return this.data.currentUser;
  }

  getChains() {
    return this.data.chains.filter(c => c.status !== ChainStatus.FAILED);
  }

  startChain(user: User): Chain | null {
    if (this.data.roundStatus === RoundStatus.COMPLETED) return null;
    
    const newChain: Chain = {
      id: `CH-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      starter: user,
      timeLeft: 60,
      status: ChainStatus.ACTIVE,
      createdAt: Date.now()
    };
    this.data.chains.push(newChain);
    this.save();
    return newChain;
  }

  joinChain(chainId: string, user: User): Chain | null {
    if (this.data.roundStatus === RoundStatus.COMPLETED) return null;

    const chain = this.data.chains.find(c => c.id === chainId);
    if (!chain || chain.status !== ChainStatus.ACTIVE) return null;

    // Prevent same user joining twice
    if (chain.starter?.id === user.id || chain.connector?.id === user.id) return chain;

    if (!chain.connector) {
      chain.connector = user;
      chain.timeLeft += 15;
    } else if (!chain.finisher) {
      chain.finisher = user;
      chain.timeLeft += 15;
      
      // WIN LOGIC: Check if someone already won this round
      if (this.data.roundStatus === RoundStatus.OPEN) {
        chain.status = ChainStatus.WON;
        chain.completedAt = Date.now();
        this.data.roundStatus = RoundStatus.COMPLETED;
        this.data.roundWinnerId = chain.id;
        
        // Mark all other active chains as lost
        this.data.chains.forEach(c => {
          if (c.id !== chain.id && c.status === ChainStatus.ACTIVE) {
            c.status = ChainStatus.LOST_TO_OTHER;
          }
        });
      }
    }

    this.save();
    return chain;
  }

  failChain(chainId: string) {
    const chain = this.data.chains.find(c => c.id === chainId);
    if (chain) {
      chain.status = ChainStatus.FAILED;
      this.save();
    }
  }

  updateTimers() {
    let changed = false;
    this.data.chains.forEach(chain => {
      if (chain.status === ChainStatus.ACTIVE) {
        chain.timeLeft -= 1;
        if (chain.timeLeft <= 0) {
          chain.status = ChainStatus.FAILED;
          changed = true;
        }
      }
    });
    if (changed) this.save();
    return [...this.data.chains];
  }

  resetRound() {
    this.data.chains = [];
    this.data.roundStatus = RoundStatus.OPEN;
    this.data.roundWinnerId = null;
    this.save();
  }
}

export const gameService = new GameService();


export enum ChainStatus {
  ACTIVE = 'active',
  FAILED = 'failed',
  WON = 'won',
  LOST_TO_OTHER = 'lost_to_other' // Round ended because someone else won first
}

export enum RoundStatus {
  OPEN = 'open',
  COMPLETED = 'completed'
}

export interface User {
  id: string;
  name: string;
  mobile: string;
  upi: string;
  verified: boolean;
}

export interface Chain {
  id: string;
  starter?: User;
  connector?: User;
  finisher?: User;
  timeLeft: number;
  status: ChainStatus;
  createdAt: number;
  completedAt?: number;
}

export interface SkillTask {
  id: string;
  type: 'ASCENDING_NUMBERS' | 'SEQUENCE_TAP' | 'SYMBOL_MATCH';
  instruction: string;
  data: any;
}


import React, { useState, useEffect } from 'react';

interface Props {
  onSuccess: () => void;
  onFail: () => void;
}

const SkillTask: React.FC<Props> = ({ onSuccess, onFail }) => {
  const [taskType] = useState(() => Math.floor(Math.random() * 3)); 
  const [timeLeft, setTimeLeft] = useState(12);
  const [data, setData] = useState<any[]>([]);
  const [target, setTarget] = useState<any>(null);
  const [userSelection, setUserSelection] = useState<any[]>([]);

  useEffect(() => {
    const handleVisibility = () => { if (document.hidden) onFail(); };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [onFail]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) { clearInterval(timer); onFail(); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [onFail]);

  useEffect(() => {
    if (taskType === 0) { // Ascending
      const nums = Array.from({ length: 5 }, () => Math.floor(Math.random() * 90) + 10);
      setData(nums);
      setTarget([...nums].sort((a, b) => a - b));
    } else if (taskType === 1) { // Sequence 1-5
      setData([1, 2, 3, 4, 5].sort(() => Math.random() - 0.5));
      setTarget([1, 2, 3, 4, 5]);
    } else { // Symbol Match
      const symbols = ['⭐', '💎', '🔥', '🌀', '🍀', '🍎'];
      const shuffled = [...symbols].sort(() => Math.random() - 0.5);
      const pick = shuffled[0];
      setTarget(pick);
      setData(shuffled);
    }
  }, [taskType]);

  const handleClick = (item: any) => {
    if (taskType === 2) {
      if (item === target) onSuccess();
      else onFail();
      return;
    }

    const nextSeq = [...userSelection, item];
    setUserSelection(nextSeq);
    if (nextSeq[nextSeq.length - 1] !== target[nextSeq.length - 1]) {
      onFail();
    } else if (nextSeq.length === target.length) {
      onSuccess();
    }
  };

  return (
    <div className="p-8 bg-slate-900 border-2 border-indigo-500 rounded-3xl shadow-2xl max-w-sm mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-indigo-400">HUMAN CHECK</h3>
        <div className="bg-red-500 text-white px-3 py-1 rounded-lg font-mono text-xl animate-pulse">
          {timeLeft}s
        </div>
      </div>

      <p className="text-slate-300 mb-8 text-center font-semibold leading-tight">
        {taskType === 0 && "Tap numbers from LOWEST to HIGHEST"}
        {taskType === 1 && "Tap digits in order: 1 → 2 → 3 → 4 → 5"}
        {taskType === 2 && `Find and tap the target: ${target}`}
      </p>

      <div className={`grid ${taskType === 2 ? 'grid-cols-3' : 'grid-cols-3'} gap-4`}>
        {data.map((item, idx) => (
          <button
            key={idx}
            disabled={userSelection.includes(item)}
            onClick={() => handleClick(item)}
            className={`h-16 rounded-2xl text-2xl font-bold transition-all transform active:scale-90 shadow-lg ${
              userSelection.includes(item) 
              ? 'bg-slate-800 text-slate-700 opacity-50' 
              : 'bg-indigo-600 hover:bg-indigo-500 text-white border-b-4 border-indigo-800'
            }`}
          >
            {item}
          </button>
        ))}
      </div>
      <p className="mt-8 text-center text-[10px] text-slate-500 uppercase tracking-widest font-bold">⚠️ TAB SWITCH = INSTANT FAIL</p>
    </div>
  );
};

export default SkillTask;
